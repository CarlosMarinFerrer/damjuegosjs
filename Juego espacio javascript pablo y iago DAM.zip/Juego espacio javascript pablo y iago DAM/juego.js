// Referencias a elementos del DOM (lo que ya existe en el HTML)
const game = document.getElementById("game");
const jugadorDOM = document.getElementById("jugador");
const info = document.getElementById("info");

// Estado global del juego (aquí vive TODO lo importante)
let estado = {
  jugador: { x: 160, y: 480, ancho: 90, alto: 90 },
  enemigos: [],
  aliados: [],
  balas: [],
  boss: null,
  gifts: [],
  vidas: 3,
  vivo: true,
  velocidad: 2
};

// Guarda qué teclas están pulsadas
let teclas = {};

/* =========================
   INPUT (TECLADO)
========================= */

// Cuando se pulsa una tecla
document.addEventListener("keydown", e => {
  teclas[e.key] = true;

  // Disparo con espacio
  if (e.key === " ") {
    estado.balas.push({
      x: estado.jugador.x + 25, // centrado mejor
      y: estado.jugador.y,
      ancho: 10,
      alto: 20
    });
  }
});

// Cuando se suelta una tecla
document.addEventListener("keyup", e => {
  teclas[e.key] = false;
});

/* =========================
   COLISIONES
========================= */

// Detecta si dos rectángulos se están tocando
function choque(a, b) {
  return !(
    a.x + a.ancho < b.x ||
    a.x > b.x + b.ancho ||
    a.y + a.alto < b.y ||
    a.y > b.y + b.alto
  );
}

/* =========================
   SPAWN INTELIGENTE (NUEVO)
========================= */

// Evita que los objetos aparezcan encima de otros
function posicionValida(x, y, ancho, alto, lista) {
  return !lista.some(obj =>
    choque({ x, y, ancho, alto }, obj)
  );
}

function generarX(ancho) {
  return Math.random() * (400 - ancho);
}

/* =========================
   CREACIÓN DE ENTIDADES
========================= */

function crearEnemigo() {
  let intentos = 0;

  while (intentos < 10) {
    let x = generarX(100);

    if (posicionValida(x, -100, 100, 100, estado.enemigos)) {
      estado.enemigos.push({
        x,
        y: -100,
        ancho: 100,
        alto: 100
      });
      break;
    }

    intentos++;
  }
}

function crearAliado() {
  let intentos = 0;

  while (intentos < 10) {
    let x = generarX(110);

    if (posicionValida(x, -100, 110, 110, estado.aliados)) {
      estado.aliados.push({
        x,
        y: -100,
        ancho: 110,
        alto: 110
      });
      break;
    }

    intentos++;
  }
}

function crearBoss() {
  estado.boss = {
    x: generarX(150),
    y: -150,
    ancho: 150,
    alto: 150,
    vida: 6
  };
}

// 🎁 Vida extra
function crearGift() {
  estado.gifts.push({
    x: generarX(80),
    y: -100,
    ancho: 80,
    alto: 80
  });
}

/* =========================
   EFECTO EXPLOSION
========================= */

function explosion(x, y) {
  let div = document.createElement("div");

  div.style.position = "absolute";
  div.style.left = x + "px";
  div.style.top = y + "px";
  div.style.width = "120px";
  div.style.height = "120px";
  div.style.backgroundImage = "url('imagenes/explosion.gif')";
  div.style.backgroundSize = "contain";
  div.style.backgroundRepeat = "no-repeat";

  game.appendChild(div);

  setTimeout(() => div.remove(), 600);
}

/* =========================
   ACTUALIZAR JUEGO
========================= */

function actualizar() {
  if (!estado.vivo) return;

  /* MOVIMIENTO DEL JUGADOR */
  if (teclas["ArrowLeft"]) estado.jugador.x -= 6;
  if (teclas["ArrowRight"]) estado.jugador.x += 6;
  if (teclas["ArrowUp"]) estado.jugador.y -= 6;
  if (teclas["ArrowDown"]) estado.jugador.y += 6;

  /* LIMITES DE PANTALLA */
  estado.jugador.x = Math.max(0, Math.min(310, estado.jugador.x));
  estado.jugador.y = Math.max(0, Math.min(510, estado.jugador.y));

  /* MOVIMIENTO DE OBJETOS */
  estado.enemigos.forEach(e => e.y += estado.velocidad);
  estado.aliados.forEach(a => a.y += estado.velocidad);
  estado.balas.forEach(b => b.y -= 8);
  estado.gifts.forEach(g => g.y += estado.velocidad * 2);

  /* COLISIONES */

  // Enemigos
  estado.enemigos.forEach(e => {
    if (choque(estado.jugador, e)) {
      estado.vidas--;
      e.y = 700;
    }
  });

  // Aliados (castigo)
  estado.aliados.forEach(a => {
    if (choque(estado.jugador, a)) {
      estado.vidas--;
      a.y = 700;
    }
  });

  // 🎁 Vida extra
  estado.gifts.forEach(g => {
    if (choque(estado.jugador, g)) {
      estado.vidas++;
      g.y = 700;
    }
  });

  /* BALAS */
  estado.balas.forEach(b => {

    estado.enemigos.forEach(e => {
      if (choque(b, e)) {
        e.y = 700;
        b.y = -50;
      }
    });

    estado.aliados.forEach(a => {
      if (choque(b, a)) {
        estado.vidas--;
        a.y = 700;
        b.y = -50;
      }
    });

    if (estado.boss && choque(b, estado.boss)) {
      estado.boss.vida--;
      b.y = -50;
    }
  });

  /* BOSS */
  if (estado.boss) {
    estado.boss.y += estado.velocidad;

    if (estado.boss.vida <= 0) {
      explosion(estado.boss.x, estado.boss.y);
      estado.boss = null;
      estado.vidas++; // recompensa
    }
  }

  /* SPAWN MÁS JUSTO */

  if (Math.random() < 0.01) crearEnemigo();
  if (Math.random() < 0.006) crearAliado();
  if (!estado.boss && Math.random() < 0.002) crearBoss();

  // 🎁 muy raro
  if (Math.random() < 0.0002) crearGift();

  /* LIMPIEZA */
  estado.enemigos = estado.enemigos.filter(e => e.y < 700);
  estado.aliados = estado.aliados.filter(a => a.y < 700);
  estado.balas = estado.balas.filter(b => b.y > -50);
  estado.gifts = estado.gifts.filter(g => g.y < 700);

  /* DIFICULTAD PROGRESIVA */
  estado.velocidad += 0.001;

  if (estado.vidas <= 0) estado.vivo = false;
}

/* =========================
   DIBUJAR EN PANTALLA
========================= */

function dibujar() {

  // Mover jugador
  jugadorDOM.style.left = estado.jugador.x + "px";
  jugadorDOM.style.top = estado.jugador.y + "px";

  // Limpiar todo lo anterior
  document.querySelectorAll(".enemigo,.aliado,.bala,.boss,.gift")
    .forEach(e => e.remove());

  // Dibujar enemigos
  estado.enemigos.forEach(e => {
    let d = document.createElement("div");
    d.className = "enemigo";
    d.style.left = e.x + "px";
    d.style.top = e.y + "px";
    game.appendChild(d);
  });

  // Dibujar aliados
  estado.aliados.forEach(a => {
    let d = document.createElement("div");
    d.className = "aliado";
    d.style.left = a.x + "px";
    d.style.top = a.y + "px";
    game.appendChild(d);
  });

  // Dibujar gifts 🎁
  estado.gifts.forEach(g => {
    let d = document.createElement("div");
    d.className = "gift";
    d.style.left = g.x + "px";
    d.style.top = g.y + "px";
    game.appendChild(d);
  });

  // Dibujar balas
  estado.balas.forEach(b => {
    let d = document.createElement("div");
    d.className = "bala";
    d.style.left = b.x + "px";
    d.style.top = b.y + "px";
    game.appendChild(d);
  });

  // Dibujar boss
  if (estado.boss) {
    let d = document.createElement("div");
    d.className = "boss";
    d.style.left = estado.boss.x + "px";
    d.style.top = estado.boss.y + "px";
    game.appendChild(d);
  }

  // Mostrar vidas
  info.innerHTML = "❤️ ".repeat(estado.vidas);

  if (!estado.vivo) {
    info.innerHTML = "GAME OVER";
  }
}

/* =========================
   BUCLE PRINCIPAL
========================= */

setInterval(() => {
  actualizar();
  dibujar();
}, 30);